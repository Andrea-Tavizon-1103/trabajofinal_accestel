from django.contrib import admin
from .models import Pedido

# Register your models here.
admin.site.register(Pedido)